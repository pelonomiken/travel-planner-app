package com.example.suitcasefinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class AddItemsActivity extends AppCompatActivity {

    EditText nametextAdd, desctextAdd, pricetextAdd;
    Button addbuttonAdd, viewbuttonAdd;

    ImageButton sendsmsbuttonAdd;

    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_items);

        nametextAdd = findViewById(R.id.editTextItemName);
        desctextAdd = findViewById(R.id.editTextItemDesc);
        pricetextAdd = findViewById(R.id.editTextItemPrice);
        addbuttonAdd = findViewById(R.id.buttonAddItem);
        viewbuttonAdd = findViewById(R.id.buttonViewItem);
        sendsmsbuttonAdd = findViewById(R.id.imageButtonSendMessage);


        DB = new DBHelper(this);

        viewbuttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AddItemsActivity.this, HomeActivity.class));
            }
        });

        addbuttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name_txt = nametextAdd.getText().toString();
                String desc_txt = desctextAdd.getText().toString();
                String price_txt = pricetextAdd.getText().toString();

                /*Checking if the method from the dbhelper class will create an item if not display that data can not be added */

                Boolean checkinsertdata = DB.createItem(name_txt, desc_txt, price_txt);
                if (checkinsertdata == true) {
                    Toast.makeText(AddItemsActivity.this, "New Item Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AddItemsActivity.this, "New data not inserted", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
   /* item delegation
Was trying to implemnt a method which would allow me to send a message to my desirable contact based on the input data when one clicks
the send button to send a message,I was not able to achive what i had wanted but implementation of how i would have liked the execution is below
       /sendsmsbuttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M);
                if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                    sendMessage();
                }else{
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS},1);

                }
            }
        });


    }

    public void sendMessage(){
        String name_txt = nametextAdd.getText().toString();
        String desc_txt = desctextAdd.getText().toString();
        String price_txt = pricetextAdd.getText().toString();


        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(name_txt,null,desc_txt,null,null);
            Toast.makeText(this, "Message is sent", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "Message not sent", Toast.LENGTH_SHORT).show();
        }

    }*/

