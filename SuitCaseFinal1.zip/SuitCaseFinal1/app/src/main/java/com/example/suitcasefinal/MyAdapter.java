package com.example.suitcasefinal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context context;
    private ArrayList itemname, itemdesc, itemprice;

    Activity activity;

    public MyAdapter(Context context,Activity activity, ArrayList itemname, ArrayList itemdesc, ArrayList itemprice) {
        this.activity = activity;
        this.context = context;
        this.itemname = itemname;
        this.itemdesc = itemdesc;
        this.itemprice = itemprice;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.home_row, parent, false);
        return new MyViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.name_txt.setText(String.valueOf(itemname.get(position)));
        holder.desc_txt.setText(String.valueOf(itemdesc.get(position)));
        holder.price_txt.setText(String.valueOf(itemprice.get(position)));


        holder.viewc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateItemsActivity.class);
                intent.putExtra("name",String.valueOf( itemname.get(position)));
                intent.putExtra("description",String.valueOf( itemdesc.get(position)));
                intent.putExtra("price",String.valueOf( itemprice.get(position)));
                activity.startActivityForResult(intent,1);
            }
        });

    }

    @Override
    public int getItemCount() {
        return itemname.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name_txt, desc_txt, price_txt;

        Button editButton;

        CardView viewc;

        CheckBox checkBox;
        TextView checktext;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            name_txt = itemView.findViewById(R.id.textViewItemName);
            desc_txt = itemView.findViewById(R.id.textViewItemDesc);
            price_txt = itemView.findViewById(R.id.textViewItemPrice);
            viewc = itemView.findViewById(R.id.cardView);
            checkBox= itemView.findViewById(R.id.checkBoxHR);
            checktext = itemView.findViewById(R.id.textViewHR);

            boolean isChecked = checkBox.isChecked();

            Poptext(isChecked);

            checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    boolean isChecked = ((CheckBox)view).isChecked();
                    Poptext(isChecked);
                }
            });




        }
        /*Mark as purchased method for the input data*/
        private void Poptext(boolean isChecked){
            if (isChecked){
                checktext.setVisibility(View.VISIBLE);
            }else {
                checktext.setVisibility(View.INVISIBLE);
            }
        }
    }
}
