package com.example.suitcasefinal;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    RecyclerView createrecyclerView;
    FloatingActionButton createItemButton;


    DBHelper DB;

    ArrayList<String> item_name, item_desc, item_price;

    MyAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        createrecyclerView = findViewById(R.id.recyclerViewHome);
        createItemButton = findViewById(R.id.floatingActionButton);
        createItemButton.setOnClickListener(this);

        DB = new DBHelper(HomeActivity.this);
        item_name = new ArrayList<>();
        item_desc = new ArrayList<>();
        item_price = new ArrayList<>();
        createrecyclerView = findViewById(R.id.recyclerViewHome);


        adapter = new MyAdapter(HomeActivity.this,this, item_name,item_desc,item_price);
        createrecyclerView.setAdapter(adapter);
        createrecyclerView.setLayoutManager(new LinearLayoutManager(HomeActivity.this));

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(createrecyclerView);

        displaydata();


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==1){
            recreate();
        }
    }

    private void displaydata() {
        Cursor cursor = DB.getallItemData();
        if (cursor.getCount()==0){
            Toast.makeText(this, "No Entry Exists", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            while (cursor.moveToNext()){
                item_name.add(cursor.getString(0));
                item_desc.add(cursor.getString(1));
                item_price.add(cursor.getString(2));
            }
        }
    }



    @Override
    public void onClick(View view) {
        Intent intent = new Intent(HomeActivity.this,AddItemsActivity.class);
        startActivity(intent);

    }

    /*Use of a gesture control that allows me to delete a record without having to get into the record activity and deleting it */
    ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
            builder.setTitle("Delete item");
            builder.setMessage("Are you sure you want to delete");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    int position = viewHolder.getAdapterPosition();
                    item_name.remove(position);
                    adapter.notifyItemRemoved(position);


                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    adapter.notifyItemChanged(viewHolder.getAdapterPosition());

                }
            });

            builder.show();

        }
    };
}