package com.example.suitcasefinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.LinkedList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    /* Name of my database and the version */
    public static final String DATABASE_NAME = "suitcase.db";
    public static final int DATABASE_VERSION = 1;

    private Context context;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        /* Creating tables of the classes i would have being it user and items*/

        sqLiteDatabase.execSQL("create table users(username TEXT primary key, password TEXT)");

        sqLiteDatabase.execSQL("create table items(name TEXT primary key,description TEXT,price TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        /* Checking if the database created is present if so remove it*/
        sqLiteDatabase.execSQL("drop table if exists users");
        sqLiteDatabase.execSQL("drop table if exists items");


    }

    /*Inserting users data which will be used for login and registration,checking their credentials and passwords*/
    public boolean insertData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("username", username);
        cv.put("password", password);

        long result = db.insert("users", null, cv);
        if (result == -1) return false;
        else
            return true;
    }

    public boolean checkusername(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public boolean checkusernamepassword(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from users where username=? and password=?", new String[]{username, password});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    /*Inserting item data,reading and retrieving it and updating it.*/
    public Boolean createItem(String name, String description, String price) {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("name", name);
        cv.put("description", description);
        cv.put("price", price);

        long result = sqLiteDatabase.insert("items", null, cv);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public Cursor getallItemData() {

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from items", null);
        return cursor;
    }

    public void updateItem(String name, String description, String price) {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("name", name);
        cv.put("description", description);
        cv.put("price", price);

        long result = sqLiteDatabase.update("items", cv, "name=?", new String[]{name});
        if (result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Succesful", Toast.LENGTH_SHORT).show();
        }
    }
}
   /* Deleting an item
    public void deleteItem(String name){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        long result =  sqLiteDatabase.delete("items","name=?", new String[]{name});
        if (result== -1){
            Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show();

        }else{
            Toast.makeText(context, "Sucess", Toast.LENGTH_SHORT).show();
        }
    }
}*/



