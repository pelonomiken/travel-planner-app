package com.example.suitcasefinal;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class UpdateItemsActivity extends AppCompatActivity implements View.OnClickListener{
    EditText nametextUpdate,desctextUpdate,pricetextUpdate;
    Button updatebutton;

    ImageButton deletebuton;

    String name,description,price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_items);
        nametextUpdate = findViewById(R.id.editTextItemNameUpdate);
        desctextUpdate = findViewById(R.id.editTextItemDescUpdate);
        pricetextUpdate = findViewById(R.id.editTextItemPriceUpdate);
        updatebutton = findViewById(R.id.buttonUpdateItem);
        deletebuton = findViewById(R.id.imageButtonDelete);
        updatebutton.setOnClickListener(this);

        getItemData ();

        deletebuton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* How the delete button was going work if its wasnt iplemented at the gesture control*/
                /*DBHelper DB = new DBHelper(UpdateItemsActivity.this);
                DB.deleteItem(name);*/

            }
        });




    }

    @Override
    public void onClick(View view) {

        DBHelper DB = new DBHelper(UpdateItemsActivity.this);
        DB.updateItem(name,description,price);

    }


    /*geting input data from dbhelper and setting them when one clicks the cardview to see the deatils of individual records*/
    public void getItemData () {
        if (getIntent().hasExtra("name") && getIntent().hasExtra("description") && getIntent().hasExtra("price")) {
            //get data from intent
            name = getIntent().getStringExtra("name");
            description = getIntent().getStringExtra("description");
            price = getIntent().getStringExtra("price");

            //set intent data
            nametextUpdate.setText(name);
            desctextUpdate.setText(description);
            pricetextUpdate.setText(price);
        } else {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }

}















