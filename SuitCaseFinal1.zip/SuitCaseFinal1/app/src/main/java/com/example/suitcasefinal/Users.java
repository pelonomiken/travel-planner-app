package com.example.suitcasefinal;

public class Users {
    String username;
    String password;

    public Users() {
    }

    public Users(String username,String password) {
        this.username = username;
        this.password = password;
    }
}
